<?php /* Delete off the codes below (from here until ***** ?> line) and put in your AdSense & Firefox Referral codes */ ?>
<img src="<?php bloginfo('stylesheet_directory'); ?>/dummy_ads/adsense.png" alt="" />

<img src="<?php bloginfo('stylesheet_directory'); ?>/dummy_ads/firefox.png" alt="" />

<?php /*
<script type="text/javascript"><!--
google_ad_client = "";
google_ad_width = 120;
google_ad_height = 60;
google_ad_format = "120x60_as_rimg";
google_cpa_choice = "";
//--></script>
<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>


<script type="text/javascript"><!--
google_ad_client = "";
google_ad_width = 120;
google_ad_height = 60;
google_ad_format = "120x60_as_rimg";
google_cpa_choice = "";
//--></script>
<script type="text/javascript" src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

                ***** */ ?>

<div class="txt">
<font color="Black">Make Money With Google AdSense !</font>
</div>

<div id="topbar">
<img src="<?php bloginfo('stylesheet_directory'); ?>/images/topbar.gif" alt="" />
<div class="topbartext">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<?php /* Delete off the codes below (from here until ***** ?> line) and put in your Link Units AdSense codes */ ?>

<?php /*
<img src="<?php bloginfo('stylesheet_directory'); ?>/dummy_ads/linkunits.jpg" alt="" />
<script type="text/javascript"><!--
google_ad_client = "";
google_alternate_ad_url = "";
google_ad_width = 728;
google_ad_height = 15;
google_ad_format = "728x15_0ads_al";
google_ad_channel ="";
google_color_border = "545454";
google_color_bg = "545454";
google_color_link = "FFFFFF";
google_color_url = "FFFFFF";
google_color_text = "FFFFFF";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
                ***** */ ?>

</div>
</div> <!-- End Of Class topbar -->
