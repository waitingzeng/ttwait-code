<?php include ("header.php"); ?>

<div id="contentwrapper">

<div id="content">
	<div id="blogs">
	<br/>
        <br />

		<div class="article">
            Sorry. We cannot find the location you are looking for.
            <?php /* Put whatever message you like below this line and before <!-- End Of Class Article --> */ ?>
            
        </div> <!-- End Of Class Article -->

	</div> <!-- end blogs -->

	<div id="centerbar">
        <br/>
        <?php include ("centerbar.php"); ?>
    </div> <!-- End Of Class centerbar -->

    <div id="sidebar">
        <br/>
        <?php get_sidebar(); ?>
    </div> <!-- End Of Class sidebar -->

</div> <!-- end content -->

</div> <!-- end contentwrapper -->

<div id="footer">
	<?PHP include ("footer.php"); ?>
</div>

</div> <!-- end wrapper -->
</body>
</html>
