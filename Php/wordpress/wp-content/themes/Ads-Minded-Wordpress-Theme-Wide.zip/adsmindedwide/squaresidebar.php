<div align="center">

<?php /* Delete off the codes below (from here until ***** ?> line) and put in any ads codes with 336px wide. */ ?>
<img src="<?php bloginfo('stylesheet_directory'); ?>/dummy_ads/336x280.gif" alt="" />

<?php /*

    Google AdSense program policies allow you to place up to three ad units and one link unit on any page. So, you have to play around with the ads placements.

    <script type="text/javascript"><!--
    ch_client = "";
    ch_width = 336;
    ch_height = 160;
    ch_color_border = "#000000";
    ch_color_bg = "#FFFFFF";
    ch_color_title = "#0060C0";
    ch_color_text = "#333333";
    ch_non_contextual = 1;
    ch_default_category = "200001";
    var ch_queries = new Array( "digital cameras", "ipod shuffle", "sony playstation" );
    var ch_selected=Math.floor((Math.random()*ch_queries.length));
    ch_query = ch_queries[ch_selected];
    //--></script>
    <script  src="http://scripts.chitika.net/eminimalls/mm.js" type="text/javascript">
    </script>
    
                    ***** */ ?>

</div>
