<div align="center">

<?php /* Delete off the codes below (from here until *****  ?> line) and put in your wide skycraper (160x600) AdSense codes */ ?>
<img src="<?php bloginfo('stylesheet_directory'); ?>/dummy_ads/wideskyscraper_img.jpg" alt="" />

<?php /*
<script type="text/javascript"><!--
google_ad_client = "";
google_ad_width = 160;
google_ad_height = 600;
google_ad_format = "160x600_as";
google_ad_type = "text_image";
google_ad_channel ="";
google_color_border = "";
google_color_bg = "";
google_color_link = "";
google_color_url = "";
google_color_text = "";
//--></script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>

                ***** */ ?>

</div>
